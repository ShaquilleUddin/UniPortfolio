/*
	The Game Project Part 4 - Character Interaction
*/

// Variables for Character
var gameChar_x;
var gameChar_y;
var floorPos_y;

//  Variables For Character Movement
var isLeft;
var isRight; 
var isFalling; 
var isPlummeting; 

// Variables For Map Interaction
var waterfalls; // This is Canyons
var collectables; 
var flag; 

// Variables For Map Background
var trees_x;
var treePos_y;
var clouds;
var mountains; 

// Camera Var + Initialising 
var cameraPosX; 
cameraPosX = 0 

// Level Completion Var
var GameOver 
var GameComplete
var GameScoreCounter

function preload()
// Loading Images
{
    angrysun = loadImage("angrysun.png");
    skull = loadImage("skull.png");
}

function setup()
{
	createCanvas(1024, 576);
	floorPos_y = height * 3/4;
	gameChar_x = width/2;
	gameChar_y = floorPos_y;
    
    // Initialise Variables to False
    isLeft = false; 
    isRight = false; 
    isFalling = false; 

    // Initialising Game Score Counter
    GameScoreCounter = 0;

    collectables = 
    [
        {x_pos: 0, y_pos: 392, size: 50, isFound: false},
        {x_pos: 1250, y_pos: 392, size: 50, isFound: false},
        {x_pos: 680, y_pos: 250, size: 50, isFound: false},
        {x_pos: 1655, y_pos: 325, size: 50, isFound: false},
        {x_pos: -1550, y_pos: 350, size:50, isFound: false}, 
        {x_pos: -850, y_pos: 250, size:50, isFound: false},
        {x_pos: 2450, y_pos: 305, size:50, isFound: false},
    ]

    // Initialising Flag
    flag = 
    {
        x_pos: 2500,
        flag_top: 307,
        isReached: false
    }

    // Game Over & Game Complete Set Up 
    GameOver = false;
    GameComplete = false;

    // Array for waterfalls
    waterfalls = 
    [
        {x_pos: 200, width: 160}, 
        {x_pos: -200, width: 170}, 
        {x_pos: -800, width: 200},
        {x_pos: 1000, width: 205},
        {x_pos: 1600, width: 120},
        {x_pos: 2000, width: 180},
        {x_pos: -2500, width: 1000},
        {x_pos: 2850, width: 1000}
    ]

    // Array for Trees
    trees_x = [-1000, -325, 100, 400, 825, 1300, 1850, 2750];
    treePos_y = floorPos_y;

    // Array for Clouds
    clouds = 
    [
        {x_pos: 0, y_pos: 90}, 
        {x_pos: 400, y_pos: 95},
        {x_pos: 800, y_pos: 105},
        {x_pos: 1300, y_pos: 100},
        {x_pos: 1800, y_pos: 80},   
        {x_pos: 2500, y_pos: 95},
        {x_pos: -750, y_pos: 100},
        {x_pos: -1300, y_pos: 75}
    ]

    // Array for Mountains
    mountains =
    [
        {x_pos: 360, y_pos: 432},
        {x_pos: -1500, y_pos: 432},
        {x_pos: -750, y_pos: 432},
        {x_pos: 1450, y_pos: 432},
        {x_pos: 2200, y_pos: 432}, 
    ]

}


function draw()
{

	///////////DRAWING CODE//////////

    background("#bd1159"); //fill the sky blue

    noStroke();
    fill("#66ff66");
    rect(0, floorPos_y, width, height - floorPos_y); //draw some green ground

    // Camera
    push()
    translate(cameraPosX,0)
    cameraPosX = (-1 * gameChar_x) + (width * 0.5);

    // Draw the canyon
    for(var i=0; i < waterfalls.length; i++)
    {
    noStroke();
    fill("#50bfe6");
    rect(waterfalls[i].x_pos, floorPos_y, waterfalls[i].width, height-floorPos_y);

    // Plummeting (Falling Position)
    if((gameChar_x > waterfalls[i].x_pos && gameChar_x < waterfalls[i].x_pos + waterfalls[i].width) && (gameChar_y >= floorPos_y))
    {
        isPlummeting = true;
    }
    }

    // Angry Sun
    angrysun.resize(100,100);
    image(angrysun, gameChar_x+375, 50);

    for(var i = 0; i < mountains.length; i++)
    {
        // Mountain
        noStroke();
        // Big Mountain 
        fill("#ff9966")
        triangle(mountains[i].x_pos,mountains[i].y_pos,mountains[i].x_pos+170,mountains[i].y_pos-282,mountains[i].x_pos+360,mountains[i].y_pos)
        // Small Mountain
        fill("#ff9933")
        triangle(mountains[i].x_pos+260,mountains[i].y_pos,mountains[i].x_pos+325,mountains[i].y_pos-107,mountains[i].x_pos+390,mountains[i].y_pos)
        // Big Mountain Glacier
        fill(255,255,255)
        beginShape();
        vertex(mountains[i].x_pos+110,mountains[i].y_pos-182)
        vertex(mountains[i].x_pos+145,mountains[i].y_pos-177)
        vertex(mountains[i].x_pos+190,mountains[i].y_pos-197)
        vertex(mountains[i].x_pos+215,mountains[i].y_pos-172)
        vertex(mountains[i].x_pos+230,mountains[i].y_pos-194)
        vertex(mountains[i].x_pos+170,mountains[i].y_pos-282)
        endShape();
        // Small Mountain Glacier
        fill(255,255,255)
        beginShape();
        vertex(mountains[i].x_pos+307,mountains[i].y_pos-78)
        vertex(mountains[i].x_pos+320,mountains[i].y_pos-67)
        vertex(mountains[i].x_pos+336,mountains[i].y_pos-72)
        vertex(mountains[i].x_pos+355,mountains[i].y_pos-57)
        vertex(mountains[i].x_pos+325,mountains[i].y_pos-107)
        endShape(); 
    }

    for(var i = 0; i < clouds.length; i++)
    {
        // Cloud
        noStroke();
        fill("#ffffff");
        rect(clouds[i].x_pos,clouds[i].y_pos,175,50)
        ellipse(clouds[i].x_pos,clouds[i].y_pos+25,50,50)
        ellipse(clouds[i].x_pos+40,clouds[i].y_pos,90,75)
        ellipse(clouds[i].x_pos+70,clouds[i].y_pos-25,80,75)
        ellipse(clouds[i].x_pos+120,clouds[i].y_pos-25,90,60)
        ellipse(clouds[i].x_pos+165,clouds[i].y_pos-15,45,50)
        ellipse(clouds[i].x_pos+175,clouds[i].y_pos+25,50,50)
        // Lightning for cloud
        fill("#ffff66")
        beginShape();
        vertex(clouds[i].x_pos+70,clouds[i].y_pos+50)
        vertex(clouds[i].x_pos+55,clouds[i].y_pos+70)
        vertex(clouds[i].x_pos+70,clouds[i].y_pos+70)
        vertex(clouds[i].x_pos+55,clouds[i].y_pos+100)
        vertex(clouds[i].x_pos+100,clouds[i].y_pos+60)
        vertex(clouds[i].x_pos+80,clouds[i].y_pos+60)
        vertex(clouds[i].x_pos+85,clouds[i].y_pos+50)
        endShape();
    }    


    for(var i = 0; i < trees_x.length; i++) 
    {
        // Tree Trunk
        noStroke();
        fill(145,100,5);
        rect(trees_x[i],treePos_y,20,-125);
        // Tree Leaves
        fill("#ccff00");
        ellipse(trees_x[i]-10,treePos_y-92,60,60);
        ellipse(trees_x[i]+30,treePos_y-92,60,60);
        ellipse(trees_x[i]+10,treePos_y-92,60,60);
        ellipse(trees_x[i]+10,treePos_y-122,60,60);
        // Apple
        fill("#fd5b78   ");
        ellipse(trees_x[i]+40,treePos_y-77,10,10); 
    } 

    // Flag 
    if(dist(gameChar_x, gameChar_y, flag.x_pos, 400 ) <= 35)
    {
        flag.isReached = true;
        GameComplete = true;
    }

    if(flag.isReached == true)
    {
        //Flag
        // Flag Pole   
        noStroke();
        fill(0,0,0);
        rect(flag.x_pos,flag.flag_top,5,125)
        // Red Flag Part
        fill(255,0,0)
        rect(flag.x_pos+5,flag.flag_top,100,50)
        // White Flag Part
        fill(255,255,255)
        rect(flag.x_pos+5,flag.flag_top,100,25) 
    }

    else if(flag.isReached == false)  
    {
        //Flag
        // Flag Pole 
        noStroke();
        fill(0,0,0);
        rect(flag.x_pos,flag.flag_top,5,125)
        // Red Flag Part
        fill(255,0,0)
        rect(flag.x_pos+5,floorPos_y,100,-50)
        // White Flag Part
        fill(255,255,255)
        rect(flag.x_pos+5,floorPos_y,100,-25) 
    } 

    // Collectable Token Finding
    for(var i = 0; i < collectables.length; i++)
    {
        if(collectables[i].isFound == false)
        {
            noStroke();
            fill("#ffffff"); 
            rect(collectables[i].x_pos,collectables[i].y_pos,14,40);
            triangle(collectables[i].x_pos,collectables[i].y_pos,collectables[i].x_pos-4,collectables[i].y_pos,collectables[i].x_pos,collectables[i].y_pos+40);
            triangle(collectables[i].x_pos+14,collectables[i].y_pos,collectables[i].x_pos+18,collectables[i].y_pos,collectables[i].x_pos+14,collectables[i].y_pos+40);
            fill("#ee34d2");
            ellipse(collectables[i].x_pos+7,collectables[i].y_pos-2,25,10);
        }
        if((dist(gameChar_x, gameChar_y, collectables[i].x_pos, collectables[i].y_pos+34) <= collectables[i].size+7) && collectables[i].isFound == false)
        {
            collectables[i].isFound = true;
            GameScoreCounter += 1;
        }
    }
    console.log(gameChar_y);

    //the game character
    if((isLeft && isFalling) || (isLeft && isPlummeting))
    {   
        // Body
        stroke(0); 
        strokeWeight(1); 
        fill(200,0,0)
        rect(gameChar_x,gameChar_y-47,10,30)
        rect(gameChar_x,gameChar_y-47,-10,30)
        fill(50,50,50)
        triangle(gameChar_x,gameChar_y-32,gameChar_x-2,gameChar_y-27,gameChar_x+2,gameChar_y-27)
        // Arms
        stroke(0); 
        strokeWeight(1); 
        fill(200,0,0)
        triangle(gameChar_x-10,gameChar_y-35,gameChar_x-20,gameChar_y-42,gameChar_x-10,gameChar_y-27)
        triangle(gameChar_x+10,gameChar_y-35,gameChar_x+15,gameChar_y-17,gameChar_x+10,gameChar_y-27)
        // Hands
        stroke(0); 
        strokeWeight(1); 
        fill(0,0,0)
        ellipse(gameChar_x-20,gameChar_y-42,3,3)
        ellipse(gameChar_x+15,gameChar_y-17,3,3)
        // Eyeball Head
        stroke(0); 
        strokeWeight(1); 
        fill(255,0,0)
        ellipse(gameChar_x,gameChar_y-52,40,40)
        fill(0,0,0)
        ellipse(gameChar_x-2,gameChar_y-54,20,20)
        // Eyeball Shine
        fill(255,255,255)
        ellipse(gameChar_x+5,gameChar_y-57,10,10)
        // Legs 
        stroke(0); 
        strokeWeight(1); 
        fill(0,0,150)
        rect(gameChar_x-10,gameChar_y-17,10,10)
        rect(gameChar_x,gameChar_y-17,10,10)
        // Shoes
        stroke(0); 
        strokeWeight(1); 
        fill(225,175,150)
        ellipse(gameChar_x-6,gameChar_y-7,10,5)
        ellipse(gameChar_x+4,gameChar_y-7,10,5)
    }

    else if((isRight && isFalling) || (isRight && isPlummeting))
    {
        // Body
        stroke(0); 
        strokeWeight(1); 
        fill(200,0,0)
        rect(gameChar_x,gameChar_y-47,10,30)
        rect(gameChar_x,gameChar_y-47,-10,30)
        fill(50,50,50)
        triangle(gameChar_x,gameChar_y-32,gameChar_x-2,gameChar_y-27,gameChar_x+2,gameChar_y-27)
        // Arms
        stroke(0); 
        strokeWeight(1); 
        fill(200,0,0)
        triangle(gameChar_x-10,gameChar_y-35,gameChar_x-15,gameChar_y-17,gameChar_x-10,gameChar_y-27)
        triangle(gameChar_x+10,gameChar_y-35,gameChar_x+20,gameChar_y-42,gameChar_x+10,gameChar_y-27)
        // Hands
        stroke(0); 
        strokeWeight(1); 
        fill(0,0,0)
        ellipse(gameChar_x-15,gameChar_y-17,3,3)
        ellipse(gameChar_x+20,gameChar_y-42,3,3)
        // Eyeball Head
        stroke(0); 
        strokeWeight(1); 
        fill(255,0,0)
        ellipse(gameChar_x,gameChar_y-52,40,40)
        fill(0,0,0)
        ellipse(gameChar_x+2,gameChar_y-54  ,20,20)
        // Eyeball Shine
        fill(255,255,255)
        ellipse(gameChar_x-10,gameChar_y-57,10,10)
        // Legs 
        stroke(0); 
        strokeWeight(1); 
        fill(0,0,150)
        rect(gameChar_x-10,gameChar_y-17,10,10)
        rect(gameChar_x,gameChar_y-17,10,10)
        // Shoes
        stroke(0); 
        strokeWeight(1); 
        fill(225,175,150)
        ellipse(gameChar_x-4,gameChar_y-7,10,5)
        ellipse(gameChar_x+6,gameChar_y-7,10,5)    
    }

    else if(isLeft)
    {
        // Body
        stroke(0); 
        strokeWeight(1); 
        fill(200,0,0)
        rect(gameChar_x,gameChar_y-40,10,30)
        rect(gameChar_x,gameChar_y-40,-10,30)
        fill(50,50,50)
        triangle(gameChar_x,gameChar_y-25,gameChar_x-2,gameChar_y-20,gameChar_x+2,gameChar_y-20)
        // Arms
        stroke(0); 
        strokeWeight(1); 
        fill(200,0,0)
        triangle(gameChar_x-10,gameChar_y-42,gameChar_x-15,gameChar_y-10,gameChar_x-10,gameChar_y-20)
        triangle(gameChar_x+10,gameChar_y-42,gameChar_x+5,gameChar_y-10,gameChar_x+10,gameChar_y-20)
        // Hands
        stroke(0); 
        strokeWeight(1); 
        fill(0,0,0)
        ellipse(gameChar_x-15,gameChar_y-10,3,3)
        ellipse(gameChar_x+5,gameChar_y-10,3,3)
        // Eyeball Head
        stroke(0); 
        strokeWeight(1); 
        fill(255,0,0)
        ellipse(gameChar_x,gameChar_y-45,40,40)
        fill(0,0,0)
        ellipse(gameChar_x-2,gameChar_y-45,20,20)
        // Eyeball Shine
        fill(255,255,255)
        ellipse(gameChar_x+5,gameChar_y-50,10,10)
        // Legs 
        stroke(0); 
        strokeWeight(1); 
        fill(0,0,150)
        rect(gameChar_x-10,gameChar_y-10,10,10)
        rect(gameChar_x,gameChar_y-10,10,10)
        // Shoes
        stroke(0); 
        strokeWeight(1); 
        fill(225,175,150)
        ellipse(gameChar_x-6,gameChar_y,10,5)
        ellipse(gameChar_x+4,gameChar_y,10,5)
    }

    else if(isRight)
    {        
        // Body
        stroke(0); 
        strokeWeight(1); 
        fill(200,0,0)
        rect(gameChar_x,gameChar_y-40,10,30)
        rect(gameChar_x,gameChar_y-40,-10,30)
        fill(50,50,50)
        triangle(gameChar_x,gameChar_y-25,gameChar_x-2,gameChar_y-20,gameChar_x+2,gameChar_y-20)
        // Arms
        stroke(0); 
        strokeWeight(1); 
        fill(200,0,0)
        triangle(gameChar_x-10,gameChar_y-28,gameChar_x-5,gameChar_y-10,gameChar_x-10,gameChar_y-20)
        triangle(gameChar_x+10,gameChar_y-28,gameChar_x+15,gameChar_y-10,gameChar_x+10,gameChar_y-20)
        // Hands
        stroke(0); 
        strokeWeight(1); 
        fill(0,0,0)
        ellipse(gameChar_x-5,gameChar_y-10,3,3)
        ellipse(gameChar_x+15,gameChar_y-10,3,3)
        // Eyeball Head
        stroke(0); 
        strokeWeight(1); 
        fill(255,0,0)
        ellipse(gameChar_x,gameChar_y-45,40,40)
        fill(0,0,0)
        ellipse(gameChar_x+2,gameChar_y-45,20,20)
        // Eyeball Shine
        fill(255,255,255)
        ellipse(gameChar_x-10,gameChar_y-50,10,10)
        // Legs 
        stroke(0); 
        strokeWeight(1); 
        fill(0,0,150)
        rect(gameChar_x-10,gameChar_y-10,10,10)
        rect(gameChar_x,gameChar_y-10,10,10)
        // Shoes
        stroke(0); 
        strokeWeight(1); 
        fill(225,175,150)
        ellipse(gameChar_x-4,gameChar_y,10,5)
        ellipse(gameChar_x+6,gameChar_y,10,5)
    }
    else if(isFalling || isPlummeting) 
    {
        // Body
        stroke(0); 
        strokeWeight(1); 
        fill(200,0,0)
        rect(gameChar_x,gameChar_y-47,10,30)
        rect(gameChar_x,gameChar_y-47,-10,30)
        fill(50,50,50)
        triangle(gameChar_x,gameChar_y-32,gameChar_x-2,gameChar_y-27,gameChar_x+2,gameChar_y-27)
        // Arms
        stroke(0); 
        strokeWeight(1); 
        fill(200,0,0)
        triangle(gameChar_x-10,gameChar_y-35,gameChar_x-20,gameChar_y-42,gameChar_x-10,gameChar_y-27)
        triangle(gameChar_x+10,gameChar_y-35,gameChar_x+20,gameChar_y-42,gameChar_x+10,gameChar_y-27)
        // Hands
        stroke(0); 
        strokeWeight(1); 
        fill(0,0,0)
        ellipse(gameChar_x-20,gameChar_y-42,3,3)
        ellipse(gameChar_x+20,gameChar_y-42,3,3)
        // Eyeball Head
        stroke(0); 
        strokeWeight(1); 
        fill(255,0,0)
        ellipse(gameChar_x,gameChar_y-52,40,40)
        fill(0,0,0)
        ellipse(gameChar_x,gameChar_y-54,20,20)
        // Eyeball Shine
        fill(255,255,255)
        ellipse(gameChar_x-5,gameChar_y-62,10,10)
        // Legs 
        stroke(0); 
        strokeWeight(1); 
        fill(0,0,150)
        rect(gameChar_x-10,gameChar_y-17,10,10)
        rect(gameChar_x,gameChar_y-17,10,10)
        // Shoes
        stroke(0); 
        strokeWeight(1); 
        fill(225,175,150)
        ellipse(gameChar_x-5,gameChar_y-8,10,5)
        ellipse(gameChar_x+5,gameChar_y-8,10,5)

    }
    else
    {
        // Body
        stroke(0); 
        strokeWeight(1); 
        fill(200,0,0)
        rect(gameChar_x,gameChar_y-40,10,30)
        rect(gameChar_x,gameChar_y-40,-10,30)
        fill(50,50,50)
        triangle(gameChar_x,gameChar_y-25,gameChar_x-2,gameChar_y-20,gameChar_x+2,gameChar_y-20)
        // Arms
        stroke(0); 
        strokeWeight(1); 
        fill(200,0,0)
        triangle(gameChar_x-10,gameChar_y-28,gameChar_x-15,gameChar_y-10,gameChar_x-10,gameChar_y-20)
        triangle(gameChar_x+10,gameChar_y-28,gameChar_x+15,gameChar_y-10,gameChar_x+10,gameChar_y-20)
        // Hands
        stroke(0); 
        strokeWeight(1); 
        fill(0,0,0)
        ellipse(gameChar_x-15,gameChar_y-10,3,3)
        ellipse(gameChar_x+15,gameChar_y-10,3,3)
        // Eyeball Head
        stroke(0); 
        strokeWeight(1); 
        fill(255,0,0)
        ellipse(gameChar_x,gameChar_y-45,40,40)
        fill(0,0,0)
        ellipse(gameChar_x,gameChar_y-45,20,20)
        // Eyeball Shine
        fill(255,255,255)
        ellipse(gameChar_x-5,gameChar_y-50,10,10)
        // Legs 
        stroke(0); 
        strokeWeight(1); 
        fill(0,0,150)
        rect(gameChar_x-10,gameChar_y-10,10,10)
        rect(gameChar_x,gameChar_y-10,10,10)
        // Shoes
        stroke(0); 
        strokeWeight(1); 
        fill(225,175,150)
        ellipse(gameChar_x-5,gameChar_y,10,5)
        ellipse(gameChar_x+5,gameChar_y,10,5) 
    }

    pop()

     // Scoring System
     if(GameOver == false && GameComplete == false)
     textAlign(LEFT, TOP);
     textSize(20);
     stroke(5);
     strokeWeight(5);
     fill(255,255,255);
     text("Score: " + GameScoreCounter, 25, 25);   

    // Game Over Screen
    if(gameChar_y > 560)
    {
        isLeft = false;
        isRight = false;
        GameOver = true;
        skull.resize(500,500);
        image(skull, width/4 + 10, height/12);
        fill(255,255,255);
        textAlign(CENTER);
        textSize(50);
        stroke(5);
        text("Game Over!", width/2, height/2 - 100);
        text("Score: " + GameScoreCounter, width/2, height/2);
        text("Press Space to Restart", width/2, height/2 + 100);
    }

    if(GameComplete == true)
    {
        isLeft = false;
        isRight = false;
        fill(255,255,255);
        textAlign(CENTER);
        textSize(50);
        stroke(5);
        text("You Win!", width/2, height/2 - 100);
        text("Score: " + GameScoreCounter, width/2, height/2);
        text("Press Space to Restart", width/2, height/2 + 100);
    }

        ///////////INTERACTION CODE//////////
        //Put conditional statements to move the game character below here

    // Make game character move left/right
    if(isLeft)
    {
        gameChar_x -= 5
    }
    else if(isRight)
    {
        gameChar_x += 5
    }

    // Make game character jump and fall (gravity)
    if(isFalling == true)
    {
        gameChar_y +=2;
    }
    if(gameChar_y == floorPos_y)
    {
        isFalling = false;
    } 

    // Plummeting (Falling through the canyon) w/ Freeze
    if(isPlummeting == true)
    {
        gameChar_y +=5;
        isLeft = false;
        isRight = false;
    }

    // Game Over || Game Complete Freeze
    if(GameOver == true || GameComplete == true)
    {
        keyPressed = false;
    }
    
    // Mouse X/Y Pointer
    push();
    textSize(12);
    fill(0);
    noStroke();
    text(mouseX + "," + mouseY, mouseX,mouseY);
    pop();
}

function keyPressed()
{
	// if statements to control the animation of the character when
	// keys are pressed.

    //open up the console to see how these work
    console.log("keyPressed: " + key);
    console.log("keyPressed: " + keyCode);

    // Left Movement
    if(key == "a" || key == "A")
    {
        isLeft = true;
    }
    // Right Movement
    if(key == "d" || key == "D")
    {
            isRight = true;
    }
    // Falling Movement
    if((key == "w" || key == "W")&& isFalling == false && gameChar_y <= floorPos_y)
    {
        isFalling = true;
        gameChar_y -= 100;
    }

}

function keyReleased()
{
        // if statements to control the animation of the character when
        // keys are released.

    console.log("keyReleased: " + key);
    console.log("keyReleased: " + keyCode);

    if(key == "a" || key == "A")
    {
        isLeft = false;
    }
    else if(key == "d" || key == "D")
    {
        isRight = false;
    }

    if(keyCode == 32)
    {
        if(GameOver == true || GameComplete == true)
        {
            document.location.reload();
        }
    }
}