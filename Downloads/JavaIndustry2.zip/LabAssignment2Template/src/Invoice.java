public class Invoice {
    // Properties
    private int id; // Invoice ID
    private String description; // Description of the invoice
    private int quantity; // Quantity of the item
    private double unitPrice; // Unit price of the item
    private boolean paid; // Whether the invoice is paid or not

    // Constructor
    public Invoice(int id, String description, int quantity, double unitPrice) {
        this.id = id; // 'this' keyword is used to refer to the current object
        this.description = description; // 'this' keyword is used to refer to the current object
        this.quantity = quantity; // 'this' keyword is used to refer to the current object 
        this.unitPrice = unitPrice; // 'this' keyword is used to refer to the current object
        this.paid = false; // 'this' keyword is used to refer to the current object
    }

    // Getter and Setter for 'paid'
    public boolean isPaid() {
        return paid; // paid is a boolean, so the getter method is 'isPaid()'
    }

    public void setPaid(boolean paid) {
        this.paid = paid; // this.paid refers to the property 'paid' of the current object
    }

    // toString() method
    @Override
    public String toString() {
        return String.format("InvoiceItem[id=%d, description=%s, quantity=%d, unitPrice=%.2f, paid=%b]", // String.format() is used to format a string
                id, description, quantity, unitPrice, paid); // %d is used to format an integer, %s is used to format a string, %.2f is used to format a double
    }
}
