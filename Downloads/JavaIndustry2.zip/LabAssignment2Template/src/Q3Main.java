public class Q3Main {
    public static void main(String[] args) {
        // Test password generation
        String generatedPassword = Password.generator(16, 4, 3); // Generating a password with 16 characters, 4 symbols and 3 digits
        System.out.println("Generated Password: " + generatedPassword); // + is used to concatenate strings

        // Test password validation
        String validationStatus = Password.validatePassword(generatedPassword); // Validating the generated password
        System.out.println("Validation Status: " + validationStatus); // + is used to concatenate strings
    }
}