import java.util.Random; // Importing Random class to generate random numbers and letters for password generation and shuffling the password to make it more secure 

public class Password {
    public static String generator(int length, int symbols, int digits) {
        if (length <= 0 || symbols < 0 || digits < 0 || symbols + digits > length) { 
            throw new IllegalArgumentException("Invalid input parameters"); 
        }

        StringBuilder password = new StringBuilder(); // StringBuilder is used to store a sequence of characters, in this case, the password

        // Generate the symbols
        for (int i = 0; i < symbols; i++) {
            password.append(generateRandomSymbol()); 
        }

        // Generate the digits
        for (int i = 0; i < digits; i++) {
            password.append(generateRandomDigit());
        }

        // Generate remaining characters as letters (randomized case)
        Random random = new Random();
        for (int i = symbols + digits; i < length; i++) {
            char randomLetter = generateRandomLetter();
            if (random.nextBoolean()) {
                randomLetter = Character.toUpperCase(randomLetter);
            }
            password.append(randomLetter); 
        }

        // Shuffle the password to make it more secure
        char[] passwordArray = password.toString().toCharArray();
        for (int i = passwordArray.length - 1; i > 0; i--) {
            int index = random.nextInt(i + 1);
            char temp = passwordArray[index];
            passwordArray[index] = passwordArray[i];
            passwordArray[i] = temp;
        }

        return new String(passwordArray); // Returning the password as a string 
    }

    public static String validatePassword(String password) {
        boolean hasUpperCase = false; // boolean is used to store a true or false value, in this case, whether the password has an uppercase letter or not
        boolean hasLowerCase = false; // boolean is used to store a true or false value, in this case, whether the password has a lowercase letter or not
        boolean hasDigit = false; // boolean is used to store a true or false value, in this case, whether the password has a digit or not 
        boolean hasSymbol = false; // boolean is used to store a true or false value, in this case, whether the password has a symbol or not

        for (char c : password.toCharArray()) {
            if (Character.isUpperCase(c)) {
                hasUpperCase = true; // Setting hasUpperCase to true if the password has an uppercase letter
            } else if (Character.isLowerCase(c)) {
                hasLowerCase = true; // Setting hasLowerCase to true if the password has a lowercase letter
            } else if (Character.isDigit(c)) {
                hasDigit = true; // Setting hasDigit to true if the password has a digit
            } else {
                hasSymbol = true; // Setting hasSymbol to true if the password has a symbol
            }
        }

        if (hasUpperCase && hasLowerCase && hasDigit && hasSymbol) {
            return "Strong"; // Returning "Strong" if the password has an uppercase letter, a lowercase letter, a digit and a symbol
        } else if (hasUpperCase && hasLowerCase && hasDigit) {
            return "Moderate"; // Returning "Moderate" if the password has an uppercase letter, a lowercase letter and a digit
        } else {
            return "Weak"; // Returning "Weak" if the password does not have an uppercase letter, a lowercase letter, a digit and a symbol
        }
    }

    private static char generateRandomSymbol() {
        String symbols = "!@#$%^&*()-_=+[{]};:'\",<.>/?"; // String is used to store a sequence of characters, in this case, symbols that can be used in a password 
        return symbols.charAt(new Random().nextInt(symbols.length()));
    }

    private static char generateRandomDigit() {
        return (char) ('0' + new Random().nextInt(10)); // char is used to store a single character, in this case, a digit that can be used in a password
    }

    private static char generateRandomLetter() {
        return (char) ('a' + new Random().nextInt(26)); // char is used to store a single character, in this case, a letter that can be used in a password
    }
}