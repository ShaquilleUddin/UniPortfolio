public class Q1Main {
    public static void main(String[] args) { 
        // Creating two instances of Invoice
        Invoice invoice1 = new Invoice(1, "Item 1", 3, 10.5); // Invoice 1
        Invoice invoice2 = new Invoice(2, "Item 2", 5, 8.75); // Invoice 2

        // Printing the initial state
        System.out.println("Initial state:"); // System.out.println() is used to print a string
        System.out.println("Invoice 1: " + invoice1); // + is used to concatenate strings
        System.out.println("Invoice 2: " + invoice2); // + is used to concatenate strings

        // Updating the 'paid' status for one invoice
        invoice1.setPaid(true); // Setting the 'paid' status to true for invoice 1

        // Printing the updated state
        System.out.println("\nUpdated state:"); // \n is used to print a new line
        System.out.println("Invoice 1: " + invoice1); // + is used to concatenate strings
        System.out.println("Invoice 2: " + invoice2); // + is used to concatenate strings
    }
}
