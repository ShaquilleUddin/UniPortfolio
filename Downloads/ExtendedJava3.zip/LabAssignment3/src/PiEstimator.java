import java.util.Random;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicInteger;

public class PiEstimator {
    //number of iterations the algorithm, a larger number here should result in a more accurate estimate
    public static int numberOfDarts = 1_000_000_000;
    public static AtomicInteger within = new AtomicInteger(0);

    public static void main(String[] args) throws InterruptedException {
        ExecutorService executor = Executors.newFixedThreadPool(4);
        for (int i = 0; i < 4; i++) {
            executor.submit(() -> {
                Random r = new Random();
                for (int j = 0; j < numberOfDarts / 4; j++) {
                    //get x and y coordinates for the darts
                    double x = r.nextDouble();
                    double y = r.nextDouble();
                    //calculate the distance from the origin (0, 0) darts with a distance less than 1 are within the
                    //quarter circle so add these to within
                    double dist = Math.sqrt((x * x) + (y * y));
                    if (dist < 1) {
                        within.incrementAndGet();
                    }
                }
            });
        }
        executor.shutdown();
        executor.awaitTermination(1, java.util.concurrent.TimeUnit.HOURS);
        //estimate pi by getting proportion of darts in the quarter circle and multiplying by 4.
        double estimate = (double) within.get() / numberOfDarts * 4;
        System.out.println(estimate);
    }
}