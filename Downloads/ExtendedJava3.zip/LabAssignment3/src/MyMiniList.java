import java.util.Arrays;

public class MyMiniList<T> implements MiniList<T> {
    private T[] objectStore;
    private int size;

    @SuppressWarnings("unchecked")
    public MyMiniList() {
        objectStore = (T[]) new Object[10];
        size = 0;
    }

    @Override
    public void add(T element) {
        if (size == objectStore.length) {
            objectStore = Arrays.copyOf(objectStore, objectStore.length * 2);
        }
        objectStore[size++] = element;
    }

    @Override
    public T get(int index) {
        if (index < 0 || index >= size) {
            throw new IndexOutOfBoundsException();
        }
        return objectStore[index];
    }

    @Override
    public int getIndex(T element) {
        for (int i = 0; i < size; i++) {
            if (objectStore[i].equals(element)) {
                return i;
            }
        }
        return -1;
    }

    @Override
    public void set(int index, T element) {
        if (index < 0 || index >= size) {
            throw new IndexOutOfBoundsException();
        }
        objectStore[index] = element;
    }

    @Override
    public int size() {
        return size;
    }

    @Override
    public T remove(int index) {
        if (index < 0 || index >= size) {
            throw new IndexOutOfBoundsException();
        }
        T removedElement = objectStore[index];
        for (int i = index; i < size - 1; i++) {
            objectStore[i] = objectStore[i + 1];
        }
        size--;
        return removedElement;
    }

    @Override
    public boolean remove(T element) {
        int index = getIndex(element);
        if (index == -1) {
            return false;
        }
        remove(index);
        return true;
    }

    @Override
    public void clear() {
        for (int i = 0; i < size; i++) {
            objectStore[i] = null;
        }
        size = 0;
    }
}