module.exports = function(app, postData) {

    // Handle our routes
    app.get('/',function(req,res){ // index route
        res.render('index.ejs', postData)
    });
    app.get('/about',function(req,res){ // about route
        res.render('about.ejs', postData);
    });
    app.get('/searchpost',function(req,res){ // search route
        res.render("searchpost.ejs", postData);
    });
    app.get('/search-result', function (req, res) { // search-result route
        //searching in the database 
        res.send("You searched for: " + req.query.keyword); 
        let sql = "SELECT * FROM Post WHERE Title LIKE '%" + req.query.keyword + "%'"; // query database to get all the posts
        db.query(sql, (err, result) => {
            if (err) {
                res.redirect('./'); 
            }
            let newData = Object.assign({}, postData, {availablePost:result});
            console.log(newData)
            res.render("search-result.ejs", newData)  
         });
    });
    app.get('/register', function (req,res) { // register route
        res.render('register.ejs', postData);                                                                     
    });                                                                                                 
    app.post('/registered', function (req,res) {
        // saving data in database
        let sqlquery = "INSERT INTO Accounts (firstnaame, lastname, username, password) VALUES (?,?,?,?)"; 
        // execute sql query
        let newrecord = [req.body.firstname, req.body.lastname, req.body.username, req.body.password]; // get the new added data from the form entry
        db.query(sqlquery, newrecord, (err, result) => {
          if (err) {
            return console.error(err.message); // if error, print error message in console
          }
          else {
            res.send(' Hello '+ req.body.firstname + ' '+ req.body.lastname +' you are now registered! Your username is '+ req.body.username +' We will send an email to you at ' + req.body.email);        
          } // else print the result
        });
  });  
    
    app.get('/postlist', function(req, res) { // list route
        let sqlquery = "SELECT * FROM Post"; // query database to get all the posts 
        // execute sql query
        db.query(sqlquery, (err, result) => {
            if (err) {
                res.redirect('./'); 
            }
            let newData = Object.assign({}, postData, {availablePost:result});
            console.log(newData)
            res.render("postlist.ejs", newData)  
         });
    });
    app.get('/createpost', function (req,res) { // createpost route
        res.render('createpost.ejs', postData);                                                                   
    });   
         app.post('/postcreated', function (req,res) {
           // saving data in database
           let sqlquery = "INSERT INTO Post (Title, Description) VALUES (?,?)"; 
           // execute sql query
           let newrecord = [req.body.Title, req.body.Description]; // get the new added data from the form entry
           db.query(sqlquery, newrecord, (err, result) => {
             if (err) {
               return console.error(err.message); // if error, print error message in console
             }
             else {
               res.send(' This post is added to database, title: ' 
                         + req.body.Title + ' description: '+ req.body.Description); 
             } // else print the result
           });
     });    
    app.get('/login', function (req,res) { // login route
        res.render('login.ejs', postData);                                                                     
    });                                                                                                 
    app.post('/loggedin', function (req,res) { // registered route
        // saving data in database
        res.send(' Hello '+ req.body.username +' you are now logged in!');                                                                              
    }); 
}