# Insert data into the tables

USE myForum;

INSERT INTO post (title, description)VALUES('test', test);