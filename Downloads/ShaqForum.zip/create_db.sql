# Create database script for Berties books

# Create the database
CREATE DATABASE myForum;
USE myForum;

# Create the app user and give it access to the database
CREATE USER 'appuser'@'localhost' IDENTIFIED WITH mysql_native_password BY 'app2027';
GRANT ALL PRIVILEGES ON myForum.* TO 'appuser'@'localhost';