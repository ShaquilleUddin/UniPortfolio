/**
 * Cells workshop starter for IS51030B Graphics
 * Create a 3D sphere-shaped container of virtual "cells"
 * 
 * by Evan Raskob, 2021 <e.raskob@gold.ac.uk>
 */


// add a color property to the cell
// add a texture to the cell


let cells = []; // array of cells objects

/**
 * Initialise the cells array with a number of new Cell objects
 * 
 * @param {Integer} maxCells Number of cells for the new array
 * @returns {Array} array of new Cells objects 
 */
function createCellsArray(maxCells)
{
  // EXERCISE: finish this function. It should: 
  // Create an empty new array, fill it with maxCells number of cells, return the array

  // steps:

  // 1. create new variable for empty array (to return at end)
  // 2. add a new Cell to the array *maxCells* times (for loop?)
  // 2b. maybe use random vectors for position and velocity
  // 3. return the array variable

  let cellsarray = []

  for(let i = 0; i < maxCells; i++) {
    let randCell = new Cell(
    {
      position: createVector(random(width), random(height)), 
      velocity: p5.Vector.random2D().mult(random(1, 5)), 
      diameter: random(10,50), 
      life: random(200, 1000)
    });
    cellsarray.push(randCell); // Add the new cells to the array
  }
  return cellsarray; // Returning the array on new cells
}


/**
 * Exercise: draw each of the cells to the screen
 * @param {Array} cellsArray Array of Cell objects to draw 
 */
function drawCells3D(cellsArray){
  // Loop through the cells array, for each cell:
  // 1. update the cell (call the update function)
  // 2. draw the cell (first push the drawing matrix) 
  // 2.1. translate to cell's position
  // 2.2 draw a sphere with the cell diameter
  // 2.3 pop the drawing matrix

  for (let cell of cellsArray) 
  {
    cell.update(); // Step 1, updating the cell
    push(); // Step 2, Drawing the cell, starting with push
    translate(cell._position.x, cell._position.y, cell._position.z); // Step 2.1, translation is the movement of the cells position through all axis x ,y, and z
    sphere(cell.diameter); // Step 2.2, drawing a sphere with the diameter of the cell (which is random between 10 and 50)
    pop(); // Step 2.3, Popping the drawing to restore default settings 
  }

}



/**
 * Check collision between two cells (overlapping positions)
 * @param {Cell} cell1 
 * @param {Cell} cell2 
 * @returns {Boolean} true if collided otherwise false
 */
function checkCollision(cell1, cell2)
{
 // Exercise: finish this (see the online notes for a full explanation)
 //  
 // 1. find the distance between the two cells using p5.Vector's dist() function
 let celldist = p5.Vector.dist(cell1.getPosition(), cell2.getPosition()) // Finding the distances from cell 1 and cell 2 by using .getPosition() with p5 function Vector.dist and 

 // 2. if it is less than the sum of their radii, they are colliding
let sumofRadii = (cell1.getdiameter()/2 + cell2.getdiameter()/2) // The radius is diameter divided by 2.

 // 3. return whether they are colliding, or not 
 if(celldist > sumofRadii){
  return false; // Return false if the distance is larger than the two radii added together 
 }
 else {
  return true; // Return true if the distance is shorter than the two radii added together
 }
}


/**
 * Collide two cells together
 * @param {Array} cellsArray Array of Cell objects to draw 
 */
function collideCells(cellsArray) 
{
  // 1. go through the array
  for (let cell1 of cellsArray)
  {
    for (let cell2 of cellsArray)
    {
      if (cell1 !== cell2) // don't collide with itself or *all* cells will bounce!
      {
        if (checkCollision(cell1,cell2)) {
          // get direction of collision, from cell2 to cell1
          let collisionDirection = p5.Vector.sub(cell1.getPosition(), cell2.getPosition()).normalize();
          cell2.applyForce(collisionDirection.mult(4)); // we calculated the direction as from 2-1 so this is backwards
          cell1.applyForce(collisionDirection.mult(4)); 
        }
      }
    }
  }
}

/**
 * Constrain cells to sphere world boundaries.
 * @param {Array} cellsArray Array of Cell objects to draw 
 */
function constrainCells(cellsArray, worldCenterPos, worldDiameter) 
{
  // 1. go through the array
  for (let cell of cellsArray)
  {
    cell.constrainToSphere(worldCenterPos,worldDiameter);
  }
}



/**
 * Setup functions
 */

function setup() {
  createCanvas(800, 600, WEBGL);
  
  // Exercise 1: test out the constructor function.
  // What should you see printed in teh console if successful?

  let testCell = new Cell({
    position: createVector(1,2,3),
    velocity: createVector(-1,-2,-3),
    life: 600,
    diameter: 35
  });
  
  console.log("Testing cell:");
  console.log(testCell); 

  // This is for part 2: creating a list of cells
  // cells = createCellsArray(5);
  // console.log(cells)

  cells = createCellsArray(10); 
  console.log(cells)
}

// This function checks if the cell is alive by making sure the life of the cell is above 0 which is the dying point of the cell.
function isAlive(cell){
  return cell._life > 0; 
}

// Checks all of the cells within the cells array are alive, and filters out/removes the cells which are no longer alive determined by isAlive function.
function getAlive(cellsArray){
  return cellsArray.filter(cell => isAlive(cell));
}

///----------------------------------------------------------------------------
/// p5js draw function 
///---------------------------------------------------------------------------
function draw() {

  orbitControl(); // camera control using mouse

  //lights(); // we're using custom lights here
  directionalLight(180,180,180, 0,0,-width/2);
  directionalLight(255,255,255, 0,0,width/2);
  
  ambientLight(60);
  pointLight(200,200,200, 0,0,0, 50);
  noStroke();
  background(80); // clear screen
  fill(220);
  ambientMaterial(80, 202, 94); // magenta material
  
  // Cells that are only alive will show
  cells = getAlive(cells) 

  collideCells(cells); // handle collisions
  constrainCells(cells, createVector(0,0,0), width); // keep cells in the world
  drawCells3D(cells); // draw the cells

  // draw world boundaries
  ambientMaterial(255, 102, 94); // magenta material for subsequent objects
  sphere(width); // this is the border of the world, a little like a "skybox" in video games
}
