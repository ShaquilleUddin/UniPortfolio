public class Q2 {
    public static void main(String[] args) {
        //part 1: display even numbers between 1 and 100
        int counter = 1; // int used for integer values, counter used to count the number of even numbers
        int evenNumber = 2; // int used for integer values, evenNumber used to store the current even number

        System.out.println("First 100 even numbers from 1"); // Print Title in Terminal
        
        while (counter <= 100) { // while loop used to print the first 100 even numbers
            System.out.println(evenNumber); // Print evenNumber in Terminal
            evenNumber += 2; // increment evenNumber by 2 to get the next even number 
            counter++; // increment counter by 1 to count the number of even numbers printed
        }

         System.out.println("--------------------------------------------------"); // Print Line in Terminal

        //part 2: display odd numbers between 1 and 100
        counter = 1; // reset counter to 1 to count the number of odd numbers 
        int oddNumber = 1; // int used for integer values, oddNumber used to store the current odd number

        System.out.println("Part 2: Odd numbers between 1 and 100:"); // Print Title in Terminal

        while (counter <= 50) { // while loop used to print the first 100 odd numbers
            System.out.println(oddNumber); // Print oddNumber in Terminal
            oddNumber += 2; // increment oddNumber by 2 to get the next odd number
            counter++; // increment counter by 1 to count the number of odd numbers printed
        }

        System.out.println("--------------------------------------------------"); // Print Line in Terminal

        //part 3: display all the multiples of 4 between 1 and 100
        counter = 1; // reset counter to 1 to count the number of multiples of 4
        int multipleOfFour = 4; // int used for integer values, multipleOfFour used to store the current multiple of 4

        System.out.println("Part 3: Multiples of 4 between 1 and 100:"); // Print Title in Terminal

        while(multipleOfFour <= 100) { // while loop used to print the first 100 multiples of 4
            System.out.println(multipleOfFour); // Print multipleOfFour in Terminal
            multipleOfFour += 4; // increment multipleOfFour by 4 to get the next multiple of 4
            counter++; // increment counter by 1 to count the number of multiples of 4 printed
        }

         System.out.println("--------------------------------------------------"); // Print Line in Terminal

        //part 4: display all the numbers between 1 and 100 replacing multiples of 3 with Java
        //multiples of 5 with Script and multiples of 3 and 5 with JavaScript

        counter = 1; // reset counter to 1 to count the number of numbers printed
        int number = 1; // int used for integer values, number used to store the current number

        System.out.println("Part 4: Numbers between 1 and 100 replacing multiples of 3 with Java, multiples of 5 with Script and multiples of 3 and 5 with JavaScript:"); // Print Title in Terminal

        while (number <= 100) { // while loop used to print the first 100 numbers
            if (number % 3 == 0 && number % 5 == 0) { // if statement used to print JavaScript if number is a multiple of 3 and 5, % means dividend so if the dividend answer is equal to 0 it means it is fully divisble with no remainders or decimals as an answer. 
                System.out.println("JavaScript"); // Print JavaScript in Terminal 
            } else if (number % 3 == 0) { // else if statement used to print Java if number is a multiple of 3, % means dividend so if the dividend answer is equal to 0 it means it is fully divisble with no remainders or decimals as an answer. 
                System.out.println("Java"); // Print Java in Terminal 
            } else if (number % 5 == 0) { // else if statement used to print Script if number is a multiple of 5, % means dividend so if the dividend answer is equal to 0 it means it is fully divisble with no remainders or decimals as an answer.
                System.out.println("Script"); // Print Script in Terminal
            } else { // else statement used to print number if number is not a multiple of 3 or 5
                System.out.println(number); // Print number in Terminal
            }
            number++; // increment number by 1 to get the next number
        }

        System.out.println("--------------------------------------------------"); // Print Line in Terminal
    }
}
