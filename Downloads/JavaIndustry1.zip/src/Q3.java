public class Q3{
    public static void main(String[] args) {
        // Test the program with different salary values
        calculateTax(50000.00); // double used for decimal values, calculateTax used to store the salary value
        calculateTax(10000.00); // double used for decimal values, calculateTax used to store the salary value
        calculateTax(30000.00); // double used for decimal values, calculateTax used to store the salary value
        calculateTax(56700.00); // double used for decimal values, calculateTax used to store the salary value
        calculateTax(51305.06); // double used for decimal values, calculateTax used to store the salary value
    }

    public static void calculateTax(double salary) { // double used for decimal values, salary used to store the salary value
        double totalTax = 0.0; // double used for decimal values, totalTax used to store the total tax

        // Apply tax rules in decreasing order of tax rating (40%, 20%, 5%) 
        if (salary > 50000.00) { // if statement used to calculate tax for income over £50000
            totalTax = (salary - 50000.00) * 0.40; // 40% tax for income over £50000
            salary = 50000.00; // set salary to £50000 to calculate tax for income between £30000 and £50000
        }

        if (salary > 30000.00) { // if statement used to calculate tax for income over £30000
            totalTax += (salary - 30000.00) * 0.20; // 20% tax for income over £30000
            salary = 30000.00; // set salary to £30000 to calculate tax for income between £15000 and £30000
        }

        if (salary > 15000.00) { // if statement used to calculate tax for income over £15000
            totalTax += (salary - 15000.00) * 0.05; // 5% tax for income over £15000
        } 

        // Display the total tax to 2 decimal places
        System.out.printf("Total tax on £%.2f is £%.2f%n", salary, totalTax); // Print total tax in Terminal
    }
}

