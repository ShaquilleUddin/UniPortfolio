public class Q4 {
    public static void main(String[] args) throws java.io.IOException {
        char choice; // Variable to store the user's choice, char used for character values
        
        do { // do while loop used to print the menu and read the user's choice
            System.out.println("Answering Service For Bank Telephone"); // Print Title in Terminal
            System.out.println("1. Current accounts"); // Print Current accounts in Terminal
            System.out.println("2. Credit cards"); // Print Credit cards in Terminal
            System.out.println("3. Loans"); // Print Loans in Terminal
            System.out.println("4. Savings accounts"); // Print Savings accounts in Terminal
            System.out.println("Press 'h' to hang up."); // Print Press 'h' to hang up in Terminal
            System.out.print("Please enter your choice: "); // Print Please enter your choice in Terminal

            choice = (char) System.in.read(); // Read the user's choice

            // Consume the newline character
            while (System.in.read() != '\n'); // while loop used to read the user's choice

            switch (choice) {
                case '1': // switch statement used to print the user's choice
                    System.out.println("You have selected Current accounts."); // Print You have selected Current accounts in Terminal
                    break; // break statement used to end the switch statement
                case '2': // switch statement used to print the user's choice
                    System.out.println("You have selected Credit cards."); // Print You have selected Credit cards in Terminal
                    break; // break statement used to end the switch statement
                case '3': // switch statement used to print the user's choice
                    System.out.println("You have selected Loans."); // Print You have selected Loans in Terminal
                    break; // break statement used to end the switch statement
                case '4': // switch statement used to print the user's choice
                    System.out.println("You have selected Savings accounts."); // Print You have selected Savings accounts in Terminal
                    break; // break statement used to end the switch statement
                case 'h': // switch statement used to print the user's choice
                    System.out.println("You have hung up. Goodbye!"); // Print You have hung up. Goodbye! in Terminal
                    break; // break statement used to end the switch statement
                default: // switch statement used to print the user's choice
                    System.out.println("Invalid choice. Please try again."); // Print Invalid choice. Please try again. in Terminal
            }
        } while (choice != 'h'); // while loop used to print the menu and read the user's choice, h will be used to hang up in the terminal.
    }
}
