public class Q1 {
    public static void main(String[] args) {
        // Defining Variables For Employee Reference
        int idNumber = 12345; // int used for integer values
        String name = "Jack Smith"; // string used for text values
        int age = 52;  // int used for integer values
        double salary = 27736.80; // double used for decimal values

        // Calculate years until retirement 
        int retirementAge = 66; // int used for integer values (assuming retirement at age 66)
        int yearsToRetirement = retirementAge - age; // int used for integer values, calculated by subtracting age from retirement age 

        // Calculate hourly rate (assuming 35-hour workweek and 52 weeks in a year)
        double weeklyHours = 35; // double used for decimal values, assuming 35-hour workweek
        double weeksInYear = 52; // double used for decimal values, assuming 52 weeks in a year
        double yearlySalary = salary; // double used for decimal values, assuming salary is yearly
        double hourlyRate = yearlySalary / (weeklyHours * weeksInYear); // double used for decimal values, calculated by dividing yearly salary by weekly hours and weeks in a year

        // Print Employee Reference in Terminal 
        System.out.println("Employee Reference"); // Print Title in Terminal
        System.out.println("--------------------------------------------------"); // Print Line in Terminal
        System.out.println("ID Number: " + idNumber); // Print ID Number in Terminal
        System.out.println("Name: \"" + name + "\""); // Print Name in Terminal
        System.out.println("Age: " + age); // Print Age in Terminal
        System.out.println("Salary: " + String.format("%.2f", salary)); // Print Salary in Terminal 
        System.out.println("Years to Retirement: " + yearsToRetirement); // Print Years to Retirement in Terminal
        System.out.println("Hourly Rate: " + String.format("%.2f", hourlyRate)); // Print Hourly Rate in Terminal
        System.out.println("--------------------------------------------------"); // Print Line in Terminal
    }
}
