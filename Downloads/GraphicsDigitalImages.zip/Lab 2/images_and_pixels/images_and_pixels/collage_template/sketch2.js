/*

Image Collage Task 
by Shaquille Muhammad Uddin
suddi006@goldsmiths.ac.uk

Demonstration and template for different styles of compositing, blending, cropping, and scaling of images. 
For this collage I have used the world's current most googled man and world's biggest contraversionalist Andrew Tate. He has been arrested for suspicion of human trafficking and has been continuously detained since. Many believe his arrest is unjust and believe his detainment for the long time period is a breach of human rights whilst many others believe that he should be arrested, but also held accountable for his opinions that went viral over 2022.

*/

// Initialising Variables - The Images

let andrewImage; // Image of Andrew Tate from his prison arrest for suspicion of human trafficking, image source: https://www.mirror.co.uk/sport/boxing/andrew-tate-arrested-suspicion-abducting-28839106

let knight // Knight chess piece, Andrew usually has a knight piece as his logo for his podcast and his business known as "Hustlers University", image source: https://freesvg.org/chess-knight-1573819705 

let prison // Prison bars to show he is currently behind bars, image source: https://www.dreamstime.com/illustration/prison-bars.html 

let matrix // Matrix image - relevant to how he believes the world system is similar to the matrix and only those who dare can break out of its trap, image source: https://giphy.com/gifs/code-matrix-security-4knozU8q9AXvpod9qy 

function preload() {
  // Loading saved images from the assets folder
  // .png images have transparent backgrounds whilst .jpg does not. 
  andrewImage = loadImage('assets/andrew.jpg');
  prison = loadImage('assets/prison.jpg');
  knight = loadImage('assets/knight.png'); 
  matrix = loadImage('assets/matrix.gif');

  pixelDensity(1); // Helps image scaling when it is drawn
}

function setup() {  
  // Console logging information about the images
  console.info('Image dimensions');
  console.info('andrewImage:' + andrewImage.width + '/' + andrewImage.height);
  console.info('prison:' + prison.width + '/' + prison.height);
  console.info('matrix' + matrix.width + '/' + matrix.height)
  
  // Canvas size is the width and height of andrewImage
  createCanvas(andrewImage.width, andrewImage.height); 
  
  // Prison is created into a mask image
  createMask(prison); 
  
  // Inverted filter is added ot the knight image
  knight.filter(INVERT);
}

function draw(){
  // Tint is reset to full colour with 0 transparency 
  tint(255,255); // reset tint to full color and no transparency

  // Images will not blend but replace what is under them
  blendMode(REPLACE);
  imageMode(CORNER);

  // Image is draws to fully fit the canvas size
  image(andrewImage, 0, 0);  

  // Prison mask images if drawn to fit the canvas size
  drawMask(prison, width/2, height/2, width, height);
  
  // Blend is using transparency 
  blendMode(BLEND);
  colorMode(RGB);

  // Everything after this line of tint will be transparent
  tint(255,180);
  imageMode(CORNER);

  // Save state of drawing
  push(); 

  // Using loops to draw knight pieces
  let maxKnights = 4 
  // Knights starting positioning
  translate(knight.width/10, height - knight.width);
  // For Loops
  for (let knights = 0; knights < maxKnights; knights++){
  let scaling = sin(map(knights, 0, maxKnights, 0, PI)); //0-1
  image(knight, 0, 0, scaling*knight.width, ((knights % 2)+1)*scaling*knight.height);
  translate(knight.width,0); 
  }

  // Resets drawing transformations
  pop();

  // I have drawn two rectangles with the colours of 3D glasses to signify that this is situation happening in real life and real time today - it is still ongoing and no one is sure whether the contraversialist is truly a threat or not. 
  // Blendmode is set to multiply - the blend will be mixing colours together using the multiply operation
  blendMode(MULTIPLY)
  // Drawing Red Rectangle 
  fill(255, 0, 0);
  rect(50, 50, 100, 100);
  // Drawing Cyan Rectangle
  fill(0, 255, 255);
  rect(100, 100, 100, 100);
  // BlendMmode back to normal 
  blendMode(BLEND);

  // Tint set to green
  tint(0, 255, 0, 100);
  // Draw matrix gif image
  image(matrix, 0, 0, 1200, 1200);

  }

function createMask(srcImage) {
    //-------------------------------------------------------
    // --- FILTERING ----------------------------------------
    // filter images -- must be done AFTER create canvas
    // https://p5js.org/reference/#/p5/filter
    //
    srcImage.filter(BLUR,2); // make this image slightly blurry
    srcImage.filter(THRESHOLD); // turn white/black only
    srcImage.filter(ERODE); // reduce light areas
}

function drawMask(img, x, y, w, h){
  // or try screen
  blendMode(SCREEN);
  imageMode(CENTER); // draw using center coordinate
  image(img, x, y, w, h);
}