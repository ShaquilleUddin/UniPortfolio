import java.util.ArrayList; // Import ArrayList class

public class StudentMain {
    public static void main(String[] args) {
        // Create a new student using the constructor
        Student student = new Student("Shaquille M. Uddin", "Computer Science", 20, "shaq.uddin", true); // Creating a new student

        // Display student information
        System.out.println("Student Information:"); // Printing the student information
        System.out.println("Name: " + student.getName()); // Printing the student name
        System.out.println("Department: " + student.getDepartment()); // Printing the student department
        System.out.println("Age: " + student.getAge()); // Printing the student age
        System.out.println("Username: " + student.getUserName()); // Printing the student username
        System.out.println("Student Number: " + student.getStudentNumber()); // Printing the student number
        System.out.println("Full Time: " + student.isFullTime()); // Printing the student full-time status

        // Add grades to the student
        Grade grade1 = new Grade("Math", 90); // Creating a new grade, Math, 90
        Grade grade2 = new Grade("English", 85); // Creating a new grade, English, 85

        student.getGrades().add(grade1); // Adding the first grade to the student
        student.getGrades().add(grade2); // Adding the second grade to the student

        // Display student grades
        System.out.println("\nStudent Grades:"); // Printing the student grades
        for (Grade grade : student.getGrades()) { // Looping through each grade
            System.out.println(grade.getSubject() + ": " + grade.getScore() + " (Grade: " + Grade.getLetterGrade(grade.getScore()) + ")"); // Printing the grade
        }
    }

    public static class Student {
        // Private properties
        private String name; // Name
        private String department; // Department 
        private int age; // Age
        private String userName; // Username
        private String studentNumber; // Student number
        private boolean fullTime; // Full-time status

        // ArrayList to store grades
        public ArrayList<Grade> grades = new ArrayList<>();

        // Constructor
        public Student(String name, String department, int age, String studentNumber, boolean fullTime) {
            this.name = name; // Setting the name
            this.department = department; // Setting the department
            this.age = age; // Setting the age
    
            // Generating the username based on the specified format
            String firstNameInitial = name.substring(0, 1).toLowerCase(); // Getting the first initial of the first name
            String[] nameParts = name.split(" "); // Splitting the name into parts
            String lastNameFirstFour = nameParts[nameParts.length - 1].substring(0, Math.min(4, nameParts[nameParts.length - 1].length())).toLowerCase(); // Getting the first four characters of the last name
            String studentNumberFirstThree = studentNumber.substring(0, Math.min(3, studentNumber.length())); // Getting the first three characters of the student number
    
            this.userName = firstNameInitial + lastNameFirstFour + studentNumberFirstThree; // Setting the username
            this.studentNumber = studentNumber; // Setting the student number
            this.fullTime = fullTime; // Setting the full-time status
        }

        // Getter and setter methods for each property
        public String getName() { // Getter method for name
            return name; // Returning the name
        }
        public void setName(String name) { // Setter method for name
            this.name = name; // Setting the name
        }

        public String getDepartment() { // Getter method for department
            return department; // Returning the department
        }
        public void setDepartment(String department) { // Setter method for department
            this.department = department; // Setting the department
        }

        public int getAge() { // Getter method for age
            return age; // Returning the age
        }
        public void setAge(int age) { // Setter method for age
            this.age = age; // Setting the age
        }

        public String getUserName() { // Getter method for username
            return userName; // Returning the username
        }
        public void setUserName(String userName) { // Setter method for username
            this.userName = userName; // Setting the username
        }

        public String getStudentNumber() { // Getter method for student number
            return studentNumber; // Returning the student number
        }
        public void setStudentNumber(String studentNumber) { // Setter method for student number
            this.studentNumber = studentNumber; // Setting the student number
        }

        public boolean isFullTime() { // Getter method for full-time status
            return fullTime; // Returning the full-time status
        }
        public void setFullTime(boolean fullTime) { // Setter method for full-time status
            this.fullTime = fullTime; // Setting the full-time status
        }

        // Getter method for grades
        public ArrayList<Grade> getGrades() {
            return grades;
        }
    }

    // Grade class
    public static class Grade {
        // Private instance variables
        private String subject; // Subject
        private int score; // Score out of 100

        // Constructor
        public Grade(String subject, int score) { // Constructor
            this.subject = subject; // Setting the subject
            this.score = score; // Setting the score
        }

        // Getter and setter methods for subject
        public String getSubject() { // Getter method for subject
            return subject; // Returning the subject   
        }

        public void setSubject(String subject) { // Setter method for subject
            this.subject = subject; // Setting the subject
        }

        // Getter and setter methods for score
        public int getScore() { // Getter method for score
            return score; // Returning the score
        }

        public void setScore(int score) { // Setter method for score
            this.score = score; // Setting the score
        }

        // Static method to get letter grade
        public static char getLetterGrade(double score) {
            if (score >= 70) {
                return 'A'; // return A if score is greater than or equal to 70
            } else if (score >= 60) {
                return 'B'; // return B if score is greater than or equal to 60
            } else if (score >= 50) {
                return 'C'; // return C if score is greater than or equal to 50
            } else if (score >= 40) {
                return 'D'; // return D if score is greater than or equal to 40
            } else if (score >= 0 && score <= 100) {
                return 'F'; // return F if score is greater than or equal to 0 and less than or equal to 100
            } else {
                return 'E'; // return E if score is less than 0. This is an error
            }
        }
    }
}
