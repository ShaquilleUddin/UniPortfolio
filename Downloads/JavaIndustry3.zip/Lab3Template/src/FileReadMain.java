import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class FileReadMain {
    public static void main(String[] args) {
        String filePath = "metamorphosis.txt"; // String filePath is the path to the file to be read

        try {
            // Creating a File object to represent the file
            File file = new File(filePath); // File object to represent the file

            // Creating a Scanner object to read from the file
            Scanner scanner = new Scanner(file); // Scanner object to read from the file

            // Variables to store statistics
            int charCount = 0; // Character counte
            int wordCount = 0; // Word count
            int sentenceCount = 0; // Sentence count
            int paragraphCount = 0; // Paragraph count

            // Reading the file line by line
            while (scanner.hasNextLine()) {
                String line = scanner.nextLine(); // Reading the line

                // Increment character count
                charCount += line.length(); // Increment character count

                // Increment word count
                wordCount += line.split("\\s+").length; // Increment word count

                // Increment sentence count based on period (.) as sentence delimiter
                sentenceCount += line.split("\\.").length; // Increment sentence count

                // Increment paragraph count based on an empty line as a paragraph delimiter
                if (line.trim().isEmpty()) {
                    paragraphCount++; // Increment paragraph count
                }

                System.out.println(line); // Printing the line
            }

            // Outputting statistics
            System.out.println("Length in characters: " + charCount); // Printing the length of the file in characters
            System.out.println("Number of words: " + wordCount); // Printing the number of words in the file
            System.out.println("Number of sentences: " + sentenceCount); // Printing the number of sentences in the file
            System.out.println("Number of paragraphs: " + paragraphCount); // Printing the number of paragraphs in the file

            // Closing the scanner to release resources
            scanner.close();
        } catch (FileNotFoundException e) { 
            System.err.println("File not found: " + filePath); // Printing the error message
        }
    }
}
