///
/// Albers contrast squares
/// by Evan Raskob <e.raskob@gold.ac.uk>
//
/// - Demonstrating using HSB colour mode in p5js.
/// - Learning about saturation, lightness and hue using
///     background contrast.

// Experiment results - Opposite Colours
// In this opposites task I have used the HSB colour mode to create a colour palette starting with the colours that are a shade of green and a shade of purple to help display opposite colours. They are both secondary colours on the artist spectrum. The current saturation of my squares is 80, and the current value of my squares is also 80. After going through the process of trial and error by changing numbers to different values I have observed that colours best show contrast when they are paired with another colour that is not next to them in the colour spectrum (which includes the secondary colours). An example of this would be green and purple since they are not next to each other, on the other hand a bad example where the contrast of the colours may not be as strong is purple and red since they are next to each other on the colour spectrum therefore they are more likely to blend together since they are visually similar. Further experimenting with saturation and values, I have learned that the best way to create opposite colours contrast better is assigning different saturations and values to each colour. This is because the saturation and value of a colour can be used to determine how light or dark a colour is, and how colourful or grey a colour is. Therefore, if the saturation and value of the colours are different, the colours will be more visually distinct from each other.  

// Colours for right square, left square, and 
// centre square that sits in both.
// NOTE: these are of object type p5.Color

let leftColor, rightColor, centreColor;
let hueSlider, satSlider, valSlider;

function setup() {
  createCanvas(400, 400);
  
  // We can use HSB mode as follows 
  // from (https://p5js.org/reference/#/p5/colorMode):
  // Setting colorMode(HSB) lets you use the HSB system instead.
  // By default, this is colorMode(HSB, 360, 100, 100, 1). 
  // You can also use HSL instead of HSB.

  colorMode(HSB);

  let leftHueAngle = 100; // set this to something fun. 0 is red.

  // Offset for right square colour: some fraction of 
  // a circle. 180 is opposite color, 360 goes back to the same 
  // colour (360 rotation)
  let hueAngleOffset = 360/2; 

  leftColor = color(leftHueAngle, 80, 80);
  rightColor = color(leftHueAngle + hueAngleOffset, 80, 80);

  ///
  /// ----------EXERCISE FOR YOU TO DO---------------------------
  /// Try changing this to change the centre squares until
  /// they both look like different colours. Find 2 combinations
  /// of colours for outer and centre squares. What parameters
  /// worked best, and why?

  centreColor = color(90, 60, 120);

  /// ----------More advanced------------------------------------
  /// You can add slider GUI (graphical user interface) elements
  /// to help chose colours instead of typing them in.
  /// See: https://p5js.org/examples/dom-slider.html
  /// Create 3 sliders, one for each of hue angle, saturation, and value
  /// that you use in the color(hue, saturation, value) above.
  /// Make sure to use text() or console.log() to print out the values
  /// when you find one you like!
  
  /// ---------Even more advanced-------------------------------- 
  /// Use a button to display or print out or even save values you like:
  /// https://p5js.org/examples/dom-input-and-button.html

  
  ///-----OTHER WAYS TO DO THIS--------------------------------------------------------
  /// There's another way to do this using ES6 syntax...
  /// uncomment the code below to use it.
  /// For this cool trick -- write a string as `my string` and you
  /// can put a variable in it using ${variable}
  /// https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Template_literals
  
  /// hsl color is a string with hue angle (0-360),
  /// saturation (0-100%), value (0-100%)
  
  // leftColor = color(`hsl(${leftHueAngle}, 80%, 80%)`);
  
  // right colour is complimentary (180 degrees away form leftHue)
  //rightColor = color(`hsl(${leftHueAngle+hueAngleOffset}, 80%, 80%)`);
  
  // EXERCISE:
  // try changing this to change the centre squares
  // centreColor = color(`hsl(140, 70%, 60%)`);
  ///-------------------------------------------------------------

  hueSlider = createSlider(0, 360, 100);
  satSlider = createSlider(0, 100, 80);
  valSlider = createSlider(0, 100, 80);
}

function draw() {
  background(0);
  
  const h = hueSlider.value();
  const s = satSlider.value();
  const v = valSlider.value();
  const hSecond = hueSlider.value() + 180;

  noStroke();
  rectMode(CORNER);
  fill(h, s, v);
  rect(0,0,width/2,height);
  fill(hSecond, s, v);
  rect(width/2,0,width/2,height);  
  
  // Draw a smaller rectangle (of a single colour) in the middle 
  // of both squares and experiment with centreColour (above) 
  // until you find a colour that looks different in both but is
  // actually the same colour. What did you change? Share the value.
    
  fill(hSecond, s, v);
  rect(width/8, height/8, width/4, height/2); 
  fill(h, s, v)
  rect(width/2+width/8, height/8, width/4, height/2);  
  
  textSize(20);
  strokeWeight(1);
  stroke(255);
  fill(0);

  // credits: Help From Github
  text(`Hue: ${h}`, 10, 30);
  text(`Saturation: ${s}`, 10, 60);
  text(`Value: ${v}`, 10, 90); 
}