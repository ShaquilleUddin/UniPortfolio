/*
The fill background tool is a tool that allows the user to fill the canvas with a colour by clicking on the canvas. The user must hold down on the F key and then click on the canvas to fill the canvas with a colour to avoid accidental filling of the canvas. When the user left clicked on the canvas, a filled rectangle of the size of the canvas will be drawn on the canvas. 
*/

function fillCanvas() { // Constructor Function Name 
    this.icon = "assets/FillCanvasIcon.png"; // Image for the button
    this.name = "fillTool"; // Name of the tool

    canvasContainer = select("#content");
    var w = canvasContainer.size().width * 10; // Get the size of the canvas
    var h = canvasContainer.size().height * 10; // Get the size of the canvas

    this.draw = function () { // Draw the tool
        if(keyIsPressed && (key === "f" || key === "F") && mouseIsPressed && mouseButton === LEFT) // Hold F and then click mouse to fills creen with colour
            rect(-6, 0, w, h); // Draw over the size of canvas
        };
    };