/* 
The eraser tool is a tool that allows the user to erase the canvas by clicking on the canvas. When the user left clicked on the canvas, a filled white ellipse of 20px width and 20px height will be drawn on the canvas.
*/

function eraserTool() { // Constructor Function name 
  this.icon = "assets/EraserToolIcon.png"; // Image for the button
  this.name = "eraserTool"; // Name of the tool

  this.draw = function () { // Draw the tool
    let x = mouseX; // X is the mouse position
    let y = mouseY; // Y is the mouse position
    let w = 15; // Width of the ellipse
    let h = 15; // Height of the ellipse

    if (mouseIsPressed && mouseButton == LEFT) { // If the mouse is pressed
      noStroke(); // No stroke for the circle
      fill(255, 255, 255) // Set the fill to white 
      ellipse(x, y, w, h); // Draw the ellipse with the numbers above 
    }
  }
}