/*
This function is used to draw a rectangle on the canvas. When the user holds their left click on the canvas, a rectangle can be drawn and dragged into a desired place. When the left click is released, the rectangle is drawn on the canvas and set in place. 
*/

function drawRectangleTool() {
  this.icon = "assets/DrawRectangleIcon.png"; // The image that will load for the tool.
  this.name = "drawRectangleTool"; // The name of the tool.

  var startMousePosX = -1; // The starting mouse position on the X axis.
  var startMousePosY = -1; // The starting mouse position on the Y axis.
  var drawing = false; // If the user is drawing or not.

  this.draw = function () {
    if (mouseIsPressed) { // If the mouse is pressed
      if (startMousePosX == -1) { // If the startMousePosX is -1
        startMousePosX = mouseX; // StartMousePosX is the mouse position
        startMousePosY = mouseY; // StartMousePosY is the mouse position 
        drawing = true; // Drawing is true
        loadPixels(); // Load the pixels
      } else { 
        updatePixels(); // Update the pixels
        rect(startMousePosX, startMousePosY, mouseX, mouseY); // Draw the rectangle
      }
    } else if (drawing) { // If the user is drawing
      drawing = false; // Drawing is false
      startMousePosX = -1; // StartMousePosX is -1
      startMousePosY = -1; // StartMousePosY is -1
    }
  };
}
