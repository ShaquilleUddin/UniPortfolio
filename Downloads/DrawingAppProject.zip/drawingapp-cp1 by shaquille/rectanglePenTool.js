/* 
The draw rectangle tool is a tool that allows the user to draw a rectangle on the canvas by clicking on the canvas. When the user left clicked on the canvas, a filled rectangle of 100px width and 50px height will be drawn on the canvas. When the user right clicked on the canvas, a rectangle of 100px width and 50px height will be drawn on the canvas with no fill, making it outline only.
*/

function rectanglePenTool() { // Constructor function name
  this.icon = "assets/RectanglePenIcon.png"; // Image for the button
  this.name = "rectanglePenTool"; // Name of the tool

  this.draw = function () { // Draw the tool
    let x = mouseX; // X is the mouse position
    let y = mouseY; // Y is the mouse position
    let w = 25; // Width of the rectangle
    let h = 15; // Height of the rectangle

    if (mouseIsPressed && mouseButton == LEFT) { // If the mouse is pressed
      // Draw the rectangle with filled background
      rect(x-12.5, y-7.5, w, h); // Draw the rectangle with the numbers above
    } else if (mouseIsPressed && mouseButton == RIGHT) { // If the mouse is pressed with right click
      noFill(); // No fill, making it outline only
      rect(x-12.5, y-7.5, w, h); // Draw the rectangle with outline only
      fill(0); // Fill the rectangle
    }
  };
}
