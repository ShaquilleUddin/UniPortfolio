/*
The draw ellipse tool is a tool that allows the user to draw a ellipse on the canvas by clicking on the canvas. When the user left clicked on the canvas, a filled ellipse of 100px width and 100px height will be drawn on the canvas. When the user right clicked on the canvas, a ellipse of 100px width and 100px height will be drawn on the canvas with no fill, making it outline only. 
*/

function ellipsePenTool() { // Constructor Function name 
  this.icon = "assets/EllipsePenIcon.png"; // Image for the button
  this.name = "ellipsePenTool"; // Name of the tool

  this.draw = function () { // Draw the tool
    let x = mouseX; // X is the mouse position
    let y = mouseY; // Y is the mouse position
    let w = 25; // Width of the ellipse
    let h = 25; // Height of the ellipse

    if (mouseIsPressed && mouseButton == LEFT) { // If the mouse is pressed
      ellipse(x, y, w, h); // Draw the ellipse with the numbers above 
    } else if (mouseIsPressed && mouseButton == RIGHT) { // If the mouse is pressed with right click
      noFill(); // No fill, making it outline only
      ellipse(x, y, w, h); // Draw the ellipse with outline only
      fill(0); // Fill the ellipse 
    }
  };
}
