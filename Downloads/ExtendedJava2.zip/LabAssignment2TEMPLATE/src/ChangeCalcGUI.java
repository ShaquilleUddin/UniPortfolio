public class ChangeCalcGUI {
}
