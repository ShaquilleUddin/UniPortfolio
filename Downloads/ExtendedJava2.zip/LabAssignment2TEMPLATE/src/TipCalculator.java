import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class TipCalculator extends JFrame {
    private JTextField priceField, tipField, peopleField;
    private JLabel resultLabel;

    public TipCalculator() {
        setTitle("Meal Splitter"); // Set the title of the window
        setLayout(new FlowLayout()); // Set the layout of the window

        JLabel priceLabel = new JLabel("Price: "); // Create a label
        priceField = new JTextField(10); // Create a text field
        add(priceLabel); // Add the label to the window
        add(priceField); // Add the text field to the window

        JLabel tipLabel = new JLabel("Tip %: "); // Create a label
        tipField = new JTextField(10); // Create a text field
        add(tipLabel); // Add the label to the window
        add(tipField); // Add the text field to the window
 
        JLabel peopleLabel = new JLabel("People: "); // Create a label
        peopleField = new JTextField(10); // Create a text field
        add(peopleLabel); // Add the label to the window 
        add(peopleField); // Add the text field to the window

        JButton calculateButton = new JButton("Calculate"); // Create a button for calculate
        add(calculateButton); // Add the calculate button to the window

        resultLabel = new JLabel(); // Create a label
        add(resultLabel); // Add the label to the window

        calculateButton.addActionListener(new ActionListener() { // Add an action listener to the calculate button
            @Override // Override the actionPerformed method
            public void actionPerformed(ActionEvent e) { // Create a method to be called when the button is clicked
                calculateTip(); // Call the calculateTip method
            }
        });

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // Set the default close operation
        setSize(300, 200); // Set the size of the window
        setVisible(true); // Set the window to be visible
    }

    private void calculateTip() { // Create a method to calculate the tip
        try { // Try to execute the following code 
            double price = Double.parseDouble(priceField.getText()); // Get the price from the price field
            double tipPercentage = Double.parseDouble(tipField.getText()); // Get the tip percentage from the tip field
            int numberOfPeople = Integer.parseInt(peopleField.getText()); // Get the number of people from the people field

            double tipAmount = price * (tipPercentage / 100); // Calculate the tip amount
            double totalAmount = price + tipAmount; // Calculate the total amount
            double amountPerPerson = totalAmount / numberOfPeople; // Calculate the amount per person

            resultLabel.setText("Each person should pay £" + String.format("%.2f", amountPerPerson)); // Set the result label to display the amount per person
        } catch (NumberFormatException ex) { // Catch a NumberFormatException
            resultLabel.setText("Invalid input. Please enter valid numbers."); // Set the result label to display an error message
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new TipCalculator();
            }
        });
    }
}