public class Person {

    // Properties
    private String firstName; // private means only this class can access it, this is a string for firstName.
    private String surname; // this is a string for surname.
    private String team; // this is a string for team.

    // Constructor
    public Person(String firstName, String surname, String team)  { 
        this.firstName = firstName; // this.firstName is the property, firstName is the parameter.
        this.surname = surname; // this.surname is the property, surname is the parameter.
        this.team = team; // this.team is the property, team is the parameter.
    }

    // Getter methods
    public String getFirstName() { // this is a getter method for firstName.
        return firstName; // returns the firstName.
    }

    public String getSurname() { // this is a getter method for surname.
        return surname; // returns the surname.
    }

    public String getTeam() { // this is a getter method for team.
        return team; // returns team name.
    }

    // Setter methods
    public void setFirstName(String firstName) { // this is a setter method for firstName.
        this.firstName = firstName; // this.firstName is the property, firstName is the parameter.
    }

    public void setSurname(String surname) { // this is a setter method for surname.
        this.surname = surname; // this.surname is the property, surname is the parameter.
    }
 
   public void setTeam(String team) { // this is a setter method for team.
        this.team = team; // this.team is the property, team is the parameter.
    }
}
