public class Player extends Person {

    // Additional properties for Player
    private String position; // this is a string for position.
    private double fitness; // this is a double for fitness.
    private double passingAccuracy; // this is a double for passingAccuracy.
    private double shotAccuracy; // this is a double for shotAccuracy.
    private double shotFrequency; // this is a double for shotFrequency.
    private double defensiveness; // this is a double for defensiveness.
    private double aggression; // this is a double for aggression.
    private double positioning; // this is a double for positioning.
    private double dribbling; // this is a double for dribbling.
    private double chanceCreation; // this is a double for chanceCreation. 
    private double offsideAdherence; // this is a double for offsideAdherence.

    // Constructor for Player
    public Player(String firstName, String surname, String team, String position, double fitness, double passingAccuracy, double shotAccuracy, double shotFrequency, double defensiveness, double aggression, double positioning, double dribbling, double chanceCreation, double offsideAdherence) {
        super(firstName, surname, team); // super takes from the Person class.
        this.position = position; // this.position is the property, position is the parameter.
        this.fitness = fitness; // this.fitness is the property, fitness is the parameter.
        this.passingAccuracy = passingAccuracy; // this.passingAccuracy is the property, passingAccuracy is the parameter.
        this.shotAccuracy = shotAccuracy; // this.shotAccuracy is the property, shotAccuracy is the parameter.
        this.shotFrequency = shotFrequency; // this.shotFrequency is the property, shotFrequency is the parameter.
        this.defensiveness = defensiveness; // this.defensiveness is the property, defensiveness is the parameter.
        this.aggression = aggression; // this.aggression is the property, aggression is the parameter.
        this.positioning = positioning; // this.positioning is the property, positioning is the parameter.
        this.dribbling = dribbling; // this.dribbling is the property, dribbling is the parameter.
        this.chanceCreation = chanceCreation; // this.chanceCreation is the property, chanceCreation is the parameter.
        this.offsideAdherence = offsideAdherence; // this.offsideAdherence is the property, offsideAdherence is the parameter.
    }

       // Getter and setter methods for Player-specific properties
       public String getPosition() { // this is a getter method for position.
        return position; // returns position.
    }

    public void setPosition(String position) { // this is a setter method for position.
        this.position = position; // this.position is the property, position is the parameter.
    }

    public double getFitness() {
        return fitness;
    }

    public void setFitness(double fitness) {
        this.fitness = fitness;
    }

    public double getPassingAccuracy() {
        return passingAccuracy;
    }

    public void setPassingAccuracy(double passingAccuracy) {
        this.passingAccuracy = passingAccuracy;
    }

    public double getShotAccuracy() {
        return shotAccuracy;
    }

    public void setShotAccuracy(double shotAccuracy) {
        this.shotAccuracy = shotAccuracy;
    }

    public double getShotFrequency() {
        return shotFrequency;
    }

    public void setShotFrequency(double shotFrequency) {
        this.shotFrequency = shotFrequency;
    }

    public double getDefensiveness() {
        return defensiveness;
    }

    public void setDefensiveness(double defensiveness) {
        this.defensiveness = defensiveness;
    }

    public double getAggression() {
        return aggression;
    }

    public void setAggression(double aggression) {
        this.aggression = aggression;
    }

    public double getPositioning() {
        return positioning;
    }

    public void setPositioning(double positioning) {
        this.positioning = positioning;
    }

    public double getDribbling() {
        return dribbling;
    }

    public void setDribbling(double dribbling) {
        this.dribbling = dribbling;
    }

    public double getChanceCreation() {
        return chanceCreation;
    }

    public void setChanceCreation(double chanceCreation) {
        this.chanceCreation = chanceCreation;
    }

    public double getOffsideAdherence() {
        return offsideAdherence;
    }

    public void setOffsideAdherence(double offsideAdherence) {
        this.offsideAdherence = offsideAdherence;
    }
}