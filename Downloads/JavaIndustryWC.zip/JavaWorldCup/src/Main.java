import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Scanner;

public class Main {
    public static Squad[] squads = new Squad[32];

    public static void main(String[] args) {
        // Load player and manager data from CSV files
        loadPlayers("Players.csv"); // this is the method for loading players from the CSV file.
        loadManagers("Managers.csv"); // this is the method for loading managers from the CSV file.

        // Now the squads array is populated with Squad objects
    }

    // Load player data from a CSV file and create Player objects
    public static void loadPlayers(String fileName) {
        try {
            // Create a Scanner to read from the CSV file
            Scanner scanner = new Scanner(new File(fileName));

            // Skip the header row
            scanner.nextLine();

            // Process each line of the CSV file
            while (scanner.hasNextLine()) {
                // Split the line into individual data items
                String[] playerData = scanner.nextLine().split(",");
                
                // Create a new Player object using the data
                Player player = new Player(
                        playerData[0], playerData[1], playerData[2], playerData[3],
                        Double.parseDouble(playerData[4]), Double.parseDouble(playerData[5]),
                        Double.parseDouble(playerData[6]), Double.parseDouble(playerData[7]),
                        Double.parseDouble(playerData[8]), Double.parseDouble(playerData[9]),
                        Double.parseDouble(playerData[10]), Double.parseDouble(playerData[11]),
                        Double.parseDouble(playerData[12]), Double.parseDouble(playerData[13])
                );

                // Determine the team index using a hash function
                int teamIndex = determineTeamIndex(player.getTeam());

                // If the Squad at the determined index is null, create a new Squad
                if (squads[teamIndex] == null) {
                    squads[teamIndex] = new Squad(player.getTeam());
                }

                // Add the player to the Squad's list of players
                squads[teamIndex].getPlayers().add(player);
            }

            // Close the Scanner
            scanner.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }

    // Load manager data from a CSV file and create Manager objects
    public static void loadManagers(String fileName) {
        try {
            // Create a Scanner to read from the CSV file
            Scanner scanner = new Scanner(new File(fileName));

            // Skip the header row
            scanner.nextLine();

            // Process each line of the CSV file
            while (scanner.hasNextLine()) {
                // Split the line into individual data items
                String[] managerData = scanner.nextLine().split(",");
                
                // Create a new Manager object using the data
                Manager manager = new Manager(
                        managerData[0], managerData[1], managerData[2], managerData[3],
                        Double.parseDouble(managerData[4]), Double.parseDouble(managerData[5]),
                        Double.parseDouble(managerData[6]), Double.parseDouble(managerData[7])
                );

                // Determine the team index using a hash function
                int teamIndex = determineTeamIndex(manager.getTeam());

                // If the Squad at the determined index is null, create a new Squad
                if (squads[teamIndex] == null) {
                    squads[teamIndex] = new Squad(manager.getTeam());
                }

                // Set the manager for the Squad
                squads[teamIndex].setManager(manager);
            }

            // Close the Scanner
            scanner.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }

    // Determine the team index using a hash function
    private static int determineTeamIndex(String team) {
        return team.hashCode() % squads.length;
    }

    public static Team getTeam(Squad squad) {
        // Create a team object
        Team team = new Team(squad.getTeamName(), squad.getManager());

        // Get the preferred formation of the manager
        String preferredFormation = squad.getManager().getFavouredFormation();

        // Calculate the number of players needed for each position
        int defendersCount = Character.getNumericValue(preferredFormation.charAt(0));
        int midfieldersCount = Character.getNumericValue(preferredFormation.charAt(2));
        int forwardsCount = Character.getNumericValue(preferredFormation.charAt(4));

        // Get all players from the squad
        ArrayList<Player> allPlayers = squad.getPlayers();

        // Sort players based on their attributes' average using a comparator
        allPlayers.sort(Comparator.comparingDouble(player ->
                (player.getFitness() + player.getPassingAccuracy() + player.getShotAccuracy() +
                        player.getShotFrequency() + player.getDefensiveness() +
                        player.getAggression() + player.getPositioning() +
                        player.getDribbling() + player.getChanceCreation() +
                        player.getOffsideAdherence()) / 10.0
        ).reversed()); // Sort in descending order

        // Create a team with the selected players
        for (int i = 0; i < defendersCount; i++) {
            team.addPlayer(allPlayers.get(i));
        }

        for (int i = defendersCount; i < defendersCount + midfieldersCount; i++) {
            team.addPlayer(allPlayers.get(i));
        }

        for (int i = defendersCount + midfieldersCount; i < defendersCount + midfieldersCount + forwardsCount; i++) {
            team.addPlayer(allPlayers.get(i));
        }

        // Add the best goalie to the team
        team.addPlayer(getBestGoalie(allPlayers));

        return team;
    }

    // Helper method to get the best goalie from the list of players
    private static Player getBestGoalie(ArrayList<Player> players) {
        players.sort(Comparator.comparingDouble(Player::getGoalieRating).reversed()); // Sort in descending order
        return players.get(0); // Get the player with the highest goalie rating
    }
}
