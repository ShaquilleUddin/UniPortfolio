public class Manager extends Person {

    // Additional properties for Manager
    private String favouredFormation; // this is a string for favouredFormation.
    private double respect; // this is a double for respect.
    private double ability; // this is a double for ability.
    private double knowledge; // this is a double for knowledge.
    private double belief; // this is a double for belief.

    // Constructor for Manager
    public Manager(String firstName, String surname, String team, String favouredFormation, double respect, double ability, double knowledge, double belief) {
        super(firstName, surname, team); // super takes from the Person class.
        this.favouredFormation = favouredFormation; // this.favouredFormation is the property, favouredFormation is the parameter.
        this.respect = respect; // this.respect is the property, respect is the parameter.
        this.ability = ability; // this.ability is the property, ability is the parameter.
        this.knowledge = knowledge; // this.knowledge is the property, knowledge is the parameter.
        this.belief = belief; // this.belief is the property, belief is the parameter.
    }

    // Getter and setter methods for Manager-specific properties
    public String getFavouredFormation() { // this is a getter method for favouredFormation.
        return favouredFormation; // returns favouredFormation.
    }

    public void setFavouredFormation(String favouredFormation) { // this is a setter method for favouredFormation.
        this.favouredFormation = favouredFormation; // this.favouredFormation is the property, favouredFormation is the parameter.
    }

    public double getRespect() {
        return respect;
    }

    public void setRespect(double respect) {
        this.respect = respect;
    }

    public double getAbility() {
        return ability;
    }

    public void setAbility(double ability) {
        this.ability = ability;
    }

    public double getKnowledge() {
        return knowledge;
    }

    public void setKnowledge(double knowledge) {
        this.knowledge = knowledge;
    }

    public double getBelief() {
        return belief;
    }

    public void setBelief(double belief) {
        this.belief = belief;
    }
}