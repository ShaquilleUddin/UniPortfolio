import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.Scanner;

public class BookCollection {
    private ArrayList<Book> books = new ArrayList<Book>();

    //2, complete constructor that takes a string path (the BookList file name) load the books from BookList into the books arrayList
    //When complete books should have 100 items. Make sure you don't include the header row!
    BookCollection(String path) {
        try {
            File file = new File(path);
            Scanner scanner = new Scanner(file);

            if (scanner.hasNextLine()) {
                scanner.nextLine(); // Skip the header row
            }

            while (scanner.hasNextLine() && books.size() < 100) {
                String line = scanner.nextLine();
                String[] bookData = line.split(",");

                Book book = new Book(
                        bookData[0].trim(),
                        bookData[1].trim(),
                        Long.parseLong(bookData[2].trim()),
                        Integer.parseInt(bookData[3].trim()),
                        Integer.parseInt(bookData[4].trim()),
                        Integer.parseInt(bookData[5].trim())
                );

                books.add(book);
            }

            scanner.close();
        } catch (FileNotFoundException e) {
            System.err.println("File not found: " + e.getMessage());
        }
    }

    //3, Return a HashSet of all the authors in the book list
    public HashSet<String> getAuthors() {
        HashSet<String> authorsSet = new HashSet<>();

        for (Book book : books) {
            authorsSet.add(book.getAuthor());
        }

        return authorsSet;
    }

    //4, return an arrayList of books with more than 750 pages
    public ArrayList<Book> getLongBooks() {
        ArrayList<Book> longBooks = new ArrayList<>();

        for (Book book : books) {
            if (book.getPages() > 750) {
                longBooks.add(book);
            }
        }

        return longBooks;
    }

    //5, return the book if the given title is in the list.
    public Book getBookByTitle(String title) {
        for (Book book : books) {
            if (book.getTitle().equalsIgnoreCase(title)) {
                return book;
            }
        }
        return null;
    }

    //6, return an array of the 10 most popular books (That is those that currently have most copies on loan)
    public Book[] getMostPopularBooks() {
        // Sort books based on copies on loan in descending order
        Collections.sort(books, Comparator.comparingInt(Book::getCopiesOnLoan).reversed());

        // Create an array to store the 10 most popular books
        Book[] mostPopularBooks = new Book[10];

        // Copy the first 10 books (most popular) to the array
        for (int i = 0; i < 10 && i < books.size(); i++) {
            mostPopularBooks[i] = books.get(i);
        }

        return mostPopularBooks;
    }
}