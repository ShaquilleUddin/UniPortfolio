public class BookMain {
    public static void main(String[] args) {
        new BookCollection("BookList.csv");
    }
}